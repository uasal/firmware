Export Firmware README

Microchip Technology Inc. - Microchip Libero Software Release v2023.2 SP1 (Version 2023.2.0.10)

Date    :    Tue May 21 11:33:48 2024
Project :    /home/summer/projects/CGraph/firmware/Filterwheel/Libero
