#ifndef Filterwheel_HW_PLATFORM_H_
#define Filterwheel_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Microsemi SmartDesign  Thu May 23 10:14:38 2024
*
*Memory map specification for peripherals in Filterwheel
*/

/*-----------------------------------------------------------------------------
* CM3 subsystem memory map
* Initiator(s) for this subsystem: CM3 
*---------------------------------------------------------------------------*/
#define FILTERWHEEL_SB_0                0x50000000U


#endif /* Filterwheel_HW_PLATFORM_H_*/
