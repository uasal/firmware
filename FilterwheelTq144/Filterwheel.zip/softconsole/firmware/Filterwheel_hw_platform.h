#ifndef Filterwheel_HW_PLATFORM_H_
#define Filterwheel_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Microsemi SmartDesign  Tue May 21 11:33:48 2024
*
*Memory map specification for peripherals in Filterwheel
*/

/*-----------------------------------------------------------------------------
* CM3 subsystem memory map
* Initiator(s) for this subsystem: CM3 
*---------------------------------------------------------------------------*/
#define FILTERWHEEL_SB_0                0x50000000U


#endif /* Filterwheel_HW_PLATFORM_H_*/
