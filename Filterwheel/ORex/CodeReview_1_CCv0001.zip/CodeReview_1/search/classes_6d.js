var searchData=
[
  ['msg',['msg',['../structmsg.html',1,'']]],
  ['msg_5fpkt',['msg_pkt',['../structmsg__pkt.html',1,'']]]
];
