var searchData=
[
  ['sfr_5fread',['sfr_read',['../mock__accessor_8c.html#aa182967ec330395dc6d88a43a62d6177',1,'sfr_read(sfr_enum_t reg):&#160;mock_accessor.c'],['../test__accessor_8h.html#aa182967ec330395dc6d88a43a62d6177',1,'sfr_read(sfr_enum_t reg):&#160;mock_accessor.c']]],
  ['sfr_5fwrite',['sfr_write',['../mock__accessor_8c.html#a7dc4409ebb34fbdca6d02f11d0dc3e33',1,'sfr_write(sfr_enum_t reg, unsigned char val):&#160;mock_accessor.c'],['../test__accessor_8h.html#a7dc4409ebb34fbdca6d02f11d0dc3e33',1,'sfr_write(sfr_enum_t reg, unsigned char val):&#160;mock_accessor.c']]]
];
