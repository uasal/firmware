var searchData=
[
  ['xbyte_5fread',['xbyte_read',['../mock__accessor_8c.html#a91e8b2e5268ab8d20933e3399e335ebd',1,'xbyte_read(unsigned short addr):&#160;mock_accessor.c'],['../test__accessor_8h.html#a91e8b2e5268ab8d20933e3399e335ebd',1,'xbyte_read(unsigned short addr):&#160;mock_accessor.c']]],
  ['xbyte_5fwrite',['xbyte_write',['../mock__accessor_8c.html#a035d200726169b51be22fb16434d7eea',1,'xbyte_write(unsigned short addr, unsigned char val):&#160;mock_accessor.c'],['../test__accessor_8h.html#a035d200726169b51be22fb16434d7eea',1,'xbyte_write(unsigned short addr, unsigned char val):&#160;mock_accessor.c']]],
  ['xword_5fread',['xword_read',['../mock__accessor_8c.html#accb70a7ebe068946cb7c61b9161d36a8',1,'xword_read(unsigned short addr):&#160;mock_accessor.c'],['../test__accessor_8h.html#accb70a7ebe068946cb7c61b9161d36a8',1,'xword_read(unsigned short addr):&#160;mock_accessor.c']]],
  ['xword_5fwrite',['xword_write',['../mock__accessor_8c.html#aa0ae1898e487b59864096bb138aa7432',1,'xword_write(unsigned short addr, unsigned short val):&#160;mock_accessor.c'],['../test__accessor_8h.html#aa0ae1898e487b59864096bb138aa7432',1,'xword_write(unsigned short addr, unsigned short val):&#160;mock_accessor.c']]]
];
