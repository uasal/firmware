var searchData=
[
  ['cip_5ft',['cip_t',['../structcip__t.html',1,'']]],
  ['cmd_5fpkt',['cmd_pkt',['../structcmd__pkt.html',1,'']]]
];
