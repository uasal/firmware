Export Firmware README

Microchip Technology Inc. - Microchip Libero Software Release v2023.2 SP1 (Version 2023.2.0.10)

Date    :    Tue Mar  5 10:53:55 2024
Project :    C:\MicroSemiProj\DMCI_Ux2
